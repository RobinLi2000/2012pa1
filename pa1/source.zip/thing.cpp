#include "thing.h"
//do NOT include anything else, write your code below